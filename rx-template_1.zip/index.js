import ReactDOM from 'react-dom'

ReactDOM.render(
  <h1>Hello, Rx-pack</h1>,
  document.getElementById('root')
);